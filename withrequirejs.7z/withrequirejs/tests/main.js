// Requirejs Configuration Options
require.config({
    // to set the default folder
    baseUrl: '../app',
    // paths: maps ids with paths (no extension)
    paths: {
        'jasmine': ['../tests/libs/jasmine-2.5.2/jasmine'],
        'jasmine-html': ['../tests/libs/jasmine-2.5.2/jasmine-html'],
        'jasmine-boot': ['../tests/libs/jasmine-2.5.2/boot']
    },
    // shim: makes external libraries compatible with requirejs (AMD)
    shim: {
        'jasmine-html': {
            deps: ['jasmine']
        },
        'jasmine-boot': {
            deps: ['jasmine', 'jasmine-html']
        }
    }
});

require(['jasmine-boot'], function () {
    require(['specs/filterservice'], function () {
        //trigger Jasmine
        window.onload();
    })
});