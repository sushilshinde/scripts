{
    "one": "Singular sensation",
    "two": "Beady little eyes",
    "three": "Little birds pitch by my doorstep"
}
/*
 
 [{
     id: 1,
     flight: "JA-202",
     depTime: 10.00,
     arrTime: 12.00,
     brand: "JA",
     orgin: "PNQ",
     dest: "DL",
     depDate: "10/01/2017",
     price: 4000
}, {
     id: 2,
     flight: "GA-202",
     depTime: 10.00,
     arrTime: 12.00,
     brand: "GA",
     orgin: "DL",
     dest: "PNQ",
     depDate: "11/01/2017",
     price: 5000
}, {
     id: 3,
     flight: "AI-202",
     depTime: 10.00,
     arrTime: 12.00,
     brand: "AI",
     orgin: "PNQ",
     dest: "DL",
     depDate: "10/01/2017",
     price: 6000
}, {
     id: 4,
     flight: "IG-202",
     depTime: 10.00,
     arrTime: 12.00,
     brand: "IG",
     orgin: "DL",
     dest: "PNQ",
     depDate: "11/01/2017",
     price: 2000
}]
 {
     isReturn: true,
     origin: "PNQ",
     dest: "DL",
     depDate: "10/01/2017",
     retDate: "11/01/2017",
     passengers: 2,
     priceRange: [0, 10000]
 }



 var flights =



 {
     total: 10,
 	[
         {
             price: 9500.00,
             up: {
                 flight: "AI-202",
                 depTime: 10.00,
                 arrTime: 12.00
             },
             down: {
                 flight: "AI-203",
                 depTime: 8.00,
                 arrTime: 11.00
             }
 		},
         {

 		}
 	]
 }*/