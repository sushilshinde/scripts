define(['../filterservice', '../specs/testflightdata'], function (service, data) {
    var resultCount = data.length;
    console.log(resultCount);
    //1st suit
    describe("testing filter service", function () {

        console.log("One way Journey..........");

        describe("One way Journey", function () {
            var criteria, fData, expectedCount = 3;
            beforeEach(function () {
                criteria = {
                    isReturn: false,
                    origin: "PNQ",
                    dest: "DL",
                    depDate: "10/01/2017",
                    passengers: 2,
                    priceRange: [0, 10000]
                };
            });

            it("Filter result with date criteria and complete price range", function () {
                fData = service.filter(criteria, data);
                expect(fData.length).toEqual(expectedCount);
            });

            it("Filter result with price range reduced", function () {
                criteria.priceRange = [0, 7000];
                fData = service.filter(criteria, data);
                expect(fData.length).toEqual(expectedCount);
            });
        });

        //1st suit
        describe("RETURN Journey", function () {

            var criteria, fData;

            beforeEach(function () {
                criteria = {
                    isReturn: true,
                    origin: "PNQ",
                    dest: "DL",
                    depDate: "10/01/2017",
                    retDate: "15/01/2017",
                    passengers: 2,
                    priceRange: [0, 10000]
                };
            });

            it("Filter result with date criteria and complete price range", function () {
                fData = service.filter(criteria, data);
                expect(fData.length).toBeLessThan(resultCount);
            });

            it("Filter result with price range reduced", function () {
                criteria.priceRange = [0, 7000];
                fData = service.filter(criteria, data);
                expect(fData.length).toBeLessThan(resultCount);
            });

            it("ZERO result for non-existing destination ", function () {
                criteria.origin = "PNQ";
                criteria.dest = "BOM"; //test data doesn't contain BOM
                fData = service.filter(criteria, data);
                expect(fData.length).toEqual(0);
            });
        })
    });
})