require([
   'idmap', 'initui', 'app'
], function (map, ui, App) {
    App.initialize();
});