define(['searchservice', 'view/criteria', 'view/result'], function (SearchService, Criteria, Result) {
    return {
        initContainer: function () {
            $("#tabs").tabs();
        },
        initRefineSlider: function () {
            $(".slider").slider({
                    range: true,
                    max: 10000,
                    min: 0,
                    values: [0, 10000]
                })
                .slider("float", {
                    rest: "label"
                });
            $(".slider").slider({
                slide: this.refineSearch.bind(this)
            });
        },
        initForm: function () {
            $("#criteria-form-onway #depDate").datepicker({
                dateFormat: 'dd/mm/yy'
            });
            $("#criteria-form-return #depDate").datepicker({
                dateFormat: 'dd/mm/yy'
            });

            $("#retDate").datepicker({
                dateFormat: 'dd/mm/yy'
            })
        },
        init: function () {
            this.initForm();
            this.initContainer();
            this.initRefineSlider();
            $("form > #search-btn").on('click', this.criteriaSearch.bind(this));
        },
        criteriaSearch: function () {
            $("#output").html("<div style='text-align:center;padding-top:50px;'>Getting flight info...</div>");
            this.search(true);
        },
        refineSearch: function () {
            this.search(false);
        },
        search: function (mask) {
            //debugger;
            var range = $("#slider"),
                _this = this,
                values = $("#tabs .ui-tabs-panel:visible form").serializeArray(),
                criteria = {},
                data;

            for (var i in values) {
                criteria[values[i].name] = values[i].value;
            }

            criteria.isReturn = criteria.retDate ? true : false;
            criteria.priceRange = [range.slider("values", 0), range.slider("values", 1)];

            Criteria.render(criteria);
            data = SearchService.searchFlights(criteria, function (data) {
                Result.render(data);
            });

            if (mask) {
                setTimeout(function () {
                    Result.render(data, criteria);
                }.bind(this), 1);

            } else {
                Result.render(data, criteria);
            }

        }
    }
});