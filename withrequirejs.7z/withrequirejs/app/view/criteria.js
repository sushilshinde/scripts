define(function () {
    return {
        render: function (criteria) {
            var criteriaTemplate = $("#criteria-template").html();
            var criteriaHtml = Mustache.render(criteriaTemplate, criteria);
            $("#criteria").html(criteriaHtml);
        }
    }
});