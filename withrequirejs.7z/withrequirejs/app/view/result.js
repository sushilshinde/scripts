define(function () {
    return {
        render: function (data, criteria) {
            var output = $("#output"),
                template = $("#item-template").html(),
                html = Mustache.render(template, {
                    data: data,
                    "total": function () {
                        var downPrice = this.down ? this.down.price : 0;
                        return this.up.price + downPrice;
                    }
                });
            output.html(html);
        }
    }
});