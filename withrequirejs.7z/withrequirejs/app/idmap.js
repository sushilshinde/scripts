define(function () {
    window.IDMAP = {
        SEARCH_FORM_RETURN: '#criteria-form-return',
        SEARCH_FORM_ONEWAY: '#criteria-form-oneway',
        TEMPLATE_CNT: ""
    }
});