define(['dateutil'], function (dateutil) {
    return {
        filterUp: function (c, flights) {
            var upFlights = flights.filter(function (obj) {
                console.log("Comparing");
                console.log(c);

                console.log(obj);
                console.log("Flight found : " + (obj.origin === c.origin && obj.dest === c.dest && obj.depDate === c.depDate));
                return obj.origin === c.origin &&
                    obj.dest === c.dest &&
                    dateutil.compare(obj.depDate, c.depDate) === 0;
            });

            upFlights.sort(function (a, b) {
                return a.depTime - b.depTime;
            });

            return upFlights;
        },

        filterDown: function (c, flights) {
            //console.log(upFlights)
            var downFlights = [];
            
            if(!c.isReturn){return downFlights;}

            downFlights = flights.filter(function (obj) {
                return c.dest === obj.origin &&
                    obj.dest === c.origin &&
                    dateutil.compare(obj.depDate, c.retDate) === 0;
            });

            downFlights.sort(function (a, b) {
                return a.depTime - b.depTime;
            });

            return downFlights;
        },

        prepareResult: function (c, upFlights, downFlights) {
            //console.log(downFlights)\
            var result = [];
            if (upFlights && upFlights.length > 0) {
                if (c.isReturn) {
                    upFlights.forEach(function (up) {
                        downFlights.forEach(function (down) {
                            var total = up.price + down.price;
                            if (total >= c.priceRange[0] && total <= c.priceRange[1]) {
                                result.push({
                                    up: up,
                                    down: down
                                });
                            }
                        });
                    });

                } else {
                    upFlights.forEach(function (up) {
                        if (up.price >= c.priceRange[0] && up.price <= c.priceRange[1]) {
                            result.push({
                                up: up
                            });
                        }
                    });
                }
            }
            return result;
        },

        filter: function (c, flights) {
            var result = this.prepareResult(c, this.filterUp(c, flights), this.filterDown(c, flights));            
            return result ? result : [];
        }
    }
});