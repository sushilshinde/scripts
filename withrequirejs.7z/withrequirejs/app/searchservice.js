define(['filterservice'], function (FilterService) {

    var _private = {
        flights: [{
            id: 1,
            flight: "JA-202",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "JA",
            origin: "PNQ",
            dest: "DL",
            depDate: "10/01/2017",
            price: 4000
                }, {
            id: 2,
            flight: "GA-202",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "GA",
            origin: "DL",
            dest: "PNQ",
            depDate: "11/01/2017",
            price: 5000
                }, {
            id: 3,
            flight: "AI-111",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "AI",
            origin: "PNQ",
            dest: "DL",
            depDate: "10/01/2017",
            price: 6000
                }, {
            id: 4,
            flight: "IG-202",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "IG",
            origin: "DL",
            dest: "PNQ",
            depDate: "11/01/2017",
            price: 2000
                }, {
            id: 4,
            flight: "IG-444",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "IG",
            origin: "DL",
            dest: "PNQ",
            depDate: "11/01/2017",
            price: 2000
                }, {
            id: 4,
            flight: "JA-202",
            depTime: 4.00,
            arrTime: 6.00,
            brand: "JA",
            origin: "DL",
            dest: "PNQ",
            depDate: "12/01/2017",
            price: 2000
                }, {
            id: 4,
            flight: "IG-444",
            depTime: 14.00,
            arrTime: 16.00,
            brand: "IG",
            origin: "PNQ",
            dest: "DL",
            depDate: "10/01/2017",
            price: 2000
                }, {
            id: 4,
            flight: "IG-202",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "IG",
            origin: "DL",
            dest: "PNQ",
            depDate: "12/01/2017",
            price: 2000
                }, {
            id: 4,
            flight: "IG-202",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "IG",
            origin: "DL",
            dest: "PNQ",
            depDate: "15/01/2017",
            price: 2000
                }, {
            id: 4,
            flight: "IA-809",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "IA",
            origin: "DL",
            dest: "PNQ",
            depDate: "17/01/2017",
            price: 2000
                }, {
            id: 4,
            flight: "IA-888",
            depTime: 7.00,
            arrTime: 12.00,
            brand: "IG",
            origin: "PNQ",
            dest: "DL",
            depDate: "15/01/2017",
            price: 2500
                }, {
            id: 4,
            flight: "IG-903",
            depTime: 10.00,
            arrTime: 12.00,
            brand: "IG",
            origin: "DL",
            dest: "PNQ",
            depDate: "17/01/2017",
            price: 2000
        }],
        getFights: function (criteria, cb) {
            debugger;
            $.getJSON("data/flights.json", function (a, b, c) {
                    console.log('here');
                }).done(function (a, b, c) {
                    console.log("second success");
                })
                .fail(function (a, b, c) {
                    console.log("error");
                });
        }
    };

    return {
        searchFlights: function (criteria, cb) {
            return FilterService.filter(criteria, _private.flights); //_private.getFights(criteria, cb);
        }
    }
});