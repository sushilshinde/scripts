define(function () {

    $(function () {

    });

});