define(function () {

    var _private = {
        cToDate: function (strDate) {

            var parts = strDate.split("/");
            return new Date(parts[2], parts[1] - 1, parts[0]);
        }
    }

    return {
        compare: function (first, second) {
            return _private.cToDate(first).getTime() - _private.cToDate(second).getTime();
        }
    }
});