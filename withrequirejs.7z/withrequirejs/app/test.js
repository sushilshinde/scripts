define([], function () {

    var myLibrary = (function () {
        function sayHello() {
            return "ABC";
        }
        return {
            sayHello: sayHello
        };
    })();

    return myLibrary;
})