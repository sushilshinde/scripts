define(['view/search'], function (Search, Result) {

    return {
        initialize: function () {
            Search.init(Result);
        }
    }
});